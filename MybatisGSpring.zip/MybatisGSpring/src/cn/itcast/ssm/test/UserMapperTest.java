package cn.itcast.ssm.test;

import cn.itcast.ssm.mapper.UserMapper;
import cn.itcast.ssm.po.User;
import cn.itcast.ssm.po.UserExample;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

import static org.junit.Assert.*;

public class UserMapperTest {
    private ApplicationContext applicationContext;

    @Before
    public void init(){
        applicationContext = new ClassPathXmlApplicationContext("classpath:Config/ApplicationContext.xml");
    }

    @Test
    public void deleteByExample() {

    }

    @Test
    public void deleteByPrimaryKey() {
    }

    @Test
    public void selectByExample() {
        UserMapper bean = this.applicationContext.getBean(UserMapper.class);
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        criteria.andUsernameLike("%张%");
        criteria.andSexEqualTo("2");
        List<User> users = bean.selectByExample(userExample);
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Test
    public void selectByPrimaryKey() {
        UserMapper bean = this.applicationContext.getBean(UserMapper.class);
        User user = bean.selectByPrimaryKey(25);
        System.out.println(user);
    }
}